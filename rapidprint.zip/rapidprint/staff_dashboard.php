<?php
session_start();

// Ensure user is logged in and has 'staff' role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'staff') {
    // Redirect to login page if not logged in or not staff
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Module 4: Manage Printing</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .dashboard {
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: white;
            padding: 20px;
            height: 100vh;
        }
        .sidebar h2 {
            text-align: center;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .content {
            flex: 1;
            padding: 20px;
            background-color: #e9ecef;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #28a745;
            color: white;
        }
        .btn {
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            color: white;
        }
        .btn.accept {
            background-color: #28a745;
        }
        .btn.delete {
            background-color: #dc3545;
        }
        .btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <h2>Staff Panel</h2>
            <a href="staff_dashboard.php">Manage Orders</a>
            <a href="update_order.php">Order Overview</a>
            <a href="invoice_overview.php">Generated Invoice</a>
            <a href="#">Bonus </a>
            <a href="#">Staff Profile</a>
        </div>
        <div class="content">
            <h1>Staff Dashboard</h1>

            <!-- Pending Orders Table -->
            <h2>Manage Orders</h2>
            <table id="pendingOrdersTable">
                <thead>
                    <tr>
                        <th>Order Number</th>
                        <th>Item</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total Price</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (file_exists('db.php')) {
                        include 'db.php'; // Include database connection

                        $query = "SELECT * FROM orders WHERE status='Pending'";
                        $result = $conn->query($query);

                        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                            echo "<tr>";
                            echo "<td>" . $row['OrderID'] . "</td>";
                            echo "<td>" . $row['item'] . "</td>";
                            echo "<td>" . $row['quantity'] . "</td>";
                            echo "<td>RM" . $row['price'] . "</td>";
                            echo "<td>RM" . $row['total_price'] . "</td>";
                            echo "<td>" . $row['status'] . "</td>";
                            echo "<td>
                                    <button class='btn accept' onclick='acceptOrder(\"" . $row['OrderID'] . "\")'>Accept</button>
                                    <button class='btn delete' onclick='deleteOrder(\"" . $row['OrderID'] . "\")'>Delete</button>
                                  </td>";
                            echo "</tr>";
                        }

                        $conn = null;
                    } else {
                        echo "<tr><td colspan='7'>Database connection file missing.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function acceptOrder(orderId) {
            fetch(`update_order.php?action=accept&order_id=${orderId}`)
                .then(response => response.text())
                .then(data => {
                    alert(data);
                    location.reload();
                });
        }

        function deleteOrder(orderId) {
            fetch(`update_order.php?action=delete&order_id=${orderId}`)
                .then(response => response.text())
                .then(data => {
                    alert(data);
                    location.reload();
                });
        }

        function markCollected(orderId) {
            fetch(`update_order.php?action=collect&order_id=${orderId}`)
                .then(response => response.text())
                .then(data => {
                    alert(data);
                    location.reload();
                });
        }
    </script>
</body>
</html>
