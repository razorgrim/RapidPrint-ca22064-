<?php
include('includes/session.php');
include('includes/header.php');
include('includes/db.php');

// Validate session and retrieve user ID
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit();
}

$student_id = $_SESSION['id']; // Assuming this is the UserID stored in the session

// Retrieve membership and student details
$query = "SELECT 
                m.MembershipID, 
                m.UserID, 
                m.CardBalance, 
                m.MembershipStatus, 
                a.MembershipCardNum, 
                s.name AS student_name, 
                s.email AS student_email
            FROM 
                membership m
            INNER JOIN 
                student s ON m.UserID = s.id
            INNER JOIN 
                user a ON m.UserID = a.id
            WHERE 
                m.UserID = :id;

$stmt = $conn->prepare($query);
$stmt->bindParam(':id', $student_id, PDO::PARAM_INT);
$stmt->execute();
$membership = $stmt->fetch(PDO::FETCH_ASSOC);



// Generate QR Code Data
$qr_data = "Membership ID: " . $membership['MembershipID'] . "\n" .
           "Name: " . $membership['name'] . "\n" .
           "Email: " . $membership['email'] . "\n" .
           "Card Balance: " . $membership['CardBalance'] . "\n" .
           "Status: " . $membership['MembershipStatus'];
$qr_api_url = "https://chart.googleapis.com/chart?chs=200x200&cht=qr&chl=" . urlencode($qr_data);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membership Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: 
                linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
                url('assets/images/background.jpg') no-repeat center center;
            background-size: cover;
            height: 100vh;
        }
        .membership-info {
            text-align: center;
            color: #333;
            margin-top: 50px;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .membership-details {
            font-size: 18px;
            text-align: left;
            color: #555;
            margin-top: 15px;
            background-color: rgba(245, 245, 245, 0.9);
            padding: 15px;
            border-radius: 10px;
            line-height: 1.8;
            border: 1px solid #ddd;
        }
        .qr-code {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="membership-info">
        <h2>Membership Profile</h2>
        <div class="membership-details">
            <p><strong>Membership ID:</strong> <?php echo htmlspecialchars($membership['MembershipID']); ?></p>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($membership['name']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($membership['email']); ?></p>
            <p><strong>Card Balance:</strong> <?php echo htmlspecialchars($membership['CardBalance']); ?></p>
            <p><strong>Status:</strong> <?php echo htmlspecialchars($membership['MembershipStatus']); ?></p>
            <p><strong>Membership Card Number:</strong> <?php echo htmlspecialchars($membership['MembershipCardNum']); ?></p>
        </div>
        <div class="qr-code">
            <h3>QR Code</h3>
            <img src="<?php echo $qr_api_url; ?>" alt="Membership QR Code">
        </div>
    </div>
</body>
</html>
<?php include('includes/footer.php'); ?>
