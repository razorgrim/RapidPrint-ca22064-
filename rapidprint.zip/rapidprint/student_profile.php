<?php
include('includes/session.php');
include('includes/header.php');
include('includes/db.php'); // Include the database connection file

// Initialize variables
$studentDetails = [];
$editMode = false;

// Check if the user is logged in and is a student
if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'student') {
    $userId = $_SESSION['user_id'];

    // Fetch all information from the User and Student tables
    $sql = "
        SELECT 
            u.Name AS UserName, 
            u.Email, 
            u.MembershipCardNumber, 
            u.Role, 
            a.DateOfBirth, 
            a.Gender, 
            a.PhoneNumber, 
            a.Address,
            a.MatricID
        FROM user u
        LEFT JOIN student a ON u.UserID = a.UserID
        WHERE u.UserID = :userId
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
    $stmt->execute();
    $studentDetails = $stmt->fetch(PDO::FETCH_ASSOC);
}

// If form is submitted, update the details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update profile functionality
    if (isset($_POST['update'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $dateOfBirth = $_POST['date_of_birth'];
        $gender = $_POST['gender'];
        $phoneNumber = $_POST['phone_number'];
        $address = $_POST['address'];
        $matricID = $_POST['matric_id']; // MatricID to be updated

        // Update the details in the database
        $updateSql = "
            UPDATE user u
            LEFT JOIN student a ON u.UserID = a.UserID
            SET u.Name = :name, u.Email = :email, a.DateOfBirth = :dateOfBirth, a.Gender = :gender, a.PhoneNumber = :phoneNumber, a.Address = :address, a.MatricID = :matricID
            WHERE u.UserID = :userId
        ";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bindParam(':name', $name);
        $updateStmt->bindParam(':email', $email);
        $updateStmt->bindParam(':dateOfBirth', $dateOfBirth);
        $updateStmt->bindParam(':gender', $gender);
        $updateStmt->bindParam(':phoneNumber', $phoneNumber);
        $updateStmt->bindParam(':address', $address);
        $updateStmt->bindParam(':matricID', $matricID);
        $updateStmt->bindParam(':userId', $userId);

        if ($updateStmt->execute()) {
            $studentDetails['UserName'] = $name;
            $studentDetails['Email'] = $email;
            $studentDetails['DateOfBirth'] = $dateOfBirth;
            $studentDetails['Gender'] = $gender;
            $studentDetails['PhoneNumber'] = $phoneNumber;
            $studentDetails['Address'] = $address;
            $studentDetails['MatricID'] = $matricID; // Update matric ID
            $editMode = false; // Exit edit mode after successful update
        } else {
            echo "<div class='error-message'>There was an error updating your profile. Please try again.</div>";
        }
    }

    // Delete profile functionality
    if (isset($_POST['delete'])) {
        // Delete both the user and student records
        try {
            // Begin a transaction
            $conn->beginTransaction();

            // Delete student details first
            $deleteStudentSql = "DELETE FROM student WHERE UserID = :userId";
            $deleteStudentStmt = $conn->prepare($deleteStudentSql);
            $deleteStudentStmt->bindParam(':userId', $userId);
            $deleteStudentStmt->execute();

            // Delete user details
            $deleteUserSql = "DELETE FROM user WHERE UserID = :userId";
            $deleteUserStmt = $conn->prepare($deleteUserSql);
            $deleteUserStmt->bindParam(':userId', $userId);
            $deleteUserStmt->execute();

            // Commit the transaction
            $conn->commit();

            // Destroy session and log the user out
            session_destroy();
            echo "<div class='success-message'>Profile deleted successfully!</div>";
            // Redirect to homepage or login page after deletion
            header('Location: index.php');
            exit;
        } catch (Exception $e) {
            // Rollback the transaction if anything goes wrong
            $conn->rollBack();
            echo "<div class='error-message'>There was an error deleting your profile. Please try again.</div>";
        }
    }
} elseif (isset($_GET['edit'])) {
    $editMode = true; // Enable edit mode if 'edit' parameter is present in URL
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile</title>
    <script>
        // Confirm deletion before proceeding
        function confirmDelete() {
            return confirm('Are you sure you want to delete your profile? This action cannot be undone.');
        }
    </script>
</head>
<style>
body {
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
    background: 
        linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
        url('assets/images/background.jpg') no-repeat center top;
    background-size: cover;
    background-repeat: repeat-x;
    background-attachment: fixed;
    background-position: top center;
    min-height: 100vh;
}

.homepage-info {
    text-align: center;
    color: #fff;
    margin-top: 50px;
    padding: 30px;
    background-color: rgba(0, 0, 0, 0.6);
    border-radius: 10px;
    max-width: 800px;
    margin-left: auto;
    margin-right: auto;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}

.admin-info {
    font-size: 18px;
    text-align: left;
    color: black; /* Updated to black for better visibility */
    margin-top: 30px;
    background-color: rgba(245, 245, 245, 0.9);
    padding: 20px;
    border-radius: 12px;
    line-height: 1.8;
    border: 1px solid #ddd;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.admin-info p {
    margin: 12px 0;
}

.admin-info strong {
    color: #333;
}

.edit-form input,
.edit-form select {
    width: 100%;
    padding: 12px;
    margin: 12px 0;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 16px;
    background-color: #fff;
}

.edit-form input[type="submit"],
.delete-form input[type="submit"] {
    padding: 12px 15px;
    border-radius: 6px;
    border: none;
    cursor: pointer;
    transition: background-color 0.3s, transform 0.2s;
    font-size: 16px;
    width: 48%; /* Make buttons side by side */
}

.edit-button {
    display: inline-block;
    padding: 12px 24px;
    margin-top: 20px;
    background-color: #4CAF50;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-size: 15px;
    transition: background-color 0.3s, transform 0.2s;
}

.edit-button:hover {
    background-color: #45a049;
    transform: scale(1.05);
}

.edit-form input[type="submit"] {
    background-color: lightgreen; /* Light green for Edit button */
    color: white;
}

.edit-form input[type="submit"]:hover {
    background-color: #45a049;
    transform: scale(1.05);
}

.delete-form input[type="submit"] {
    background-color: red; /* Red for Delete button */
    color: white;
    padding: 10px 10px; /* Reduced padding for a smaller button */
    font-size: 15px; /* Reduced font size */
    width: 20%; /* Adjust width to make it smaller */
    border-radius: 6px;
    border: none;
    cursor: pointer;
    transition: background-color 0.3s, transform 0.2s;
}

.delete-form input[type="submit"]:hover {
    background-color: rgb(197, 86, 72); /* Slightly darker red on hover */
    transform: scale(1.05);
}



h2 {
    font-size: 28px;
    font-weight: 700;
    color: #fff;
}

label {
    font-size: 16px;
    color: #ccc;
    margin-bottom: 6px;
}

input[type="text"],
input[type="email"],
input[type="date"],
select {
    font-size: 16px;
    padding: 10px;
    width: 100%;
    margin-bottom: 15px;
    border-radius: 6px;
    border: 1px solid #ddd;
    background-color: #f9f9f9;
}

input[type="text"]:focus,
input[type="email"]:focus,
input[type="date"]:focus,
select:focus {
    border-color: #4CAF50;
    outline: none;
    background-color: #f1f1f1;
}

@media (max-width: 768px) {
    .homepage-info {
        padding: 20px;
        margin-top: 20px;
    }

    .admin-info {
        padding: 15px;
    }

    .edit-form input,
    .edit-form select {
        padding: 10px;
    }

    .edit-button,
    .edit-form input[type="submit"],
    .delete-form input[type="submit"] {
        padding: 10px 20px;
    }
}
</style>
<body>
    <div class="homepage-info">
        <h2>Student Profile</h2>

        <?php if ($editMode): ?>
            <!-- Edit Form -->
            <div class="edit-form">
                <h3>Edit Your Details</h3>
                <form method="POST">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($studentDetails['UserName']); ?>" required>

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($studentDetails['Email']); ?>" required>

                    <label for="matric_id">Matric ID:</label>
                    <input type="text" id="matric_id" name="matric_id" value="<?php echo htmlspecialchars($studentDetails['MatricID']); ?>" required>
                    
                    <label for="date_of_birth">Date of Birth:</label>
                    <input type="date" id="date_of_birth" name="date_of_birth" value="<?php echo htmlspecialchars($studentDetails['DateOfBirth']); ?>">

                    <label for="gender">Gender:</label>
                    <select id="gender" name="gender">
                        <option value="Male" <?php echo ($studentDetails['Gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                        <option value="Female" <?php echo ($studentDetails['Gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                    </select>

                    <label for="phone_number">Phone Number:</label>
                    <input type="text" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($studentDetails['PhoneNumber']); ?>">

                    <label for="address">Address:</label>
                    <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($studentDetails['Address']); ?>">

                    

                    <input type="submit" name="update" value="Update Profile">
                </form>
            </div>
        <?php else: ?>
            <!-- Display Student Info -->
            <div class="admin-info">
                <p><strong>Name:</strong> <?php echo htmlspecialchars(ucwords(strtolower($studentDetails['UserName']))); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($studentDetails['Email']); ?></p>
                <p><strong>Matric ID:</strong> <?php echo htmlspecialchars($studentDetails['MatricID']); ?></p>
                <p><strong>Membership Card Number:</strong> <?php echo htmlspecialchars($studentDetails['MembershipCardNumber']); ?></p>
                <p><strong>Role:</strong> <?php echo htmlspecialchars(ucwords($studentDetails['Role'])); ?></p>
                <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($studentDetails['DateOfBirth']); ?></p>
                <p><strong>Gender:</strong> <?php echo htmlspecialchars($studentDetails['Gender']); ?></p>
                <p><strong>Phone Number:</strong> <?php echo htmlspecialchars($studentDetails['PhoneNumber']); ?></p>
                <p><strong>Address:</strong> <?php echo htmlspecialchars($studentDetails['Address']); ?></p>
                

                <a href="?edit=true" class="edit-button">Edit Profile</a>
                <br>
                <form class="delete-form" method="POST" onsubmit="return confirmDelete();">
                    <input type="submit" name="delete" value="Delete Profile">
                </form>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

<?php include('includes/footer.php'); ?>
